<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");

?>
<!DOCTYPE html>
<html>

<head>
    <title>EZ_webSite </title>
    <link rel="stylesheet" type="text/css" media="screen" href="otrais.css" />
    <style>

body {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #ddd;
    padding: 8px;
}

tr:nth-child(even){background-color: transparent;}
tr:hover {background-color: #ddd;}

th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: transparent;
    color: white;
}

</style>
</head>

<body>
    <div class="Edgars">
        <img src="pic1.jpg.jpg" alt=" " class="Edgars-img" ;>
        <h1>
        <?php
        
        $sql="select lietVards as 'Sveiks', lietUzvards as '' from Lietotajs where liet_id = 2;";
        
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabula($sql_res);
  ?>
        </h1>
        <h5>Bakalaura programma "Datorzinātnes"</h5>

        <div class="zemEdgars">
            <form>
                <div class="info">
                    <a href="AirIndex.html">

                    </a>
                </div>
            </form>

   <div class = "zemEdgars"> <form>
           <div class = "info" >
               <a href="tresais.php">
                <div class="info" onclick="izvele('c');">
                    ITF Kursi
                </div>
             </a>
           </div></form>
                <?php
        
        $sql="select dala_virsraksts as '' from Pazinojumi;";
        
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabulaViens($sql_res);
  ?>

                <div class = "info">

         
    </div>
</form>

        </div>


    
    

      

        <br>



        <div>
            <h6>@created by EZ 2018</h6>
        </div>
    </div>
    </div>
    </div>





</body>

</html>
<?php

function tabula($sql_res) {
    $first = true;
    echo "<center> <class = \"info\"></br>";
    while ($row = mysqli_fetch_assoc($sql_res)) {
        if ($first) {
            echo "<h1></br>";
            foreach ($row as $k=>$v) {
                echo "<th>$k </th>";
            }
            echo "</tr>".PHP_EOL;
            $first = false;
        }
        echo "<tr>";
            foreach ($row as $v) {
             echo "<a href=otrais.php style= 'color:white;'> $v</a> 
                 </br>"  ;
            }
            echo "</tr>".PHP_EOL;
    }
    echo "</table></center>";
    
    
    
    /* close result set */
    mysqli_free_result($sql_res);
    }

    function tabulaViens($sql_res) {
        $first = true;
        echo "<center> <class = \"info\"></br>";
        while ($row = mysqli_fetch_assoc($sql_res)) {
            if ($first) {
                echo "<h1></br>";
                foreach ($row as $k=>$v) {
                    echo "<th>$k </th>";
                }echo "</br>";
                echo "</tr>".PHP_EOL;
                $first = false;
            }
            echo "<tr>";
                foreach ($row as $v) {
                 echo " $v 
                     "  ;
                }
                echo "</tr>".PHP_EOL;
        }
        echo "</table></center>";
        
        
        /* close result set */
        mysqli_free_result($sql_res);
        }

    
