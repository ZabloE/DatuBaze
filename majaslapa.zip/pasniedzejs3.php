
<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");

?>


<!DOCTYPE html>
<html>

<head>
    <title>EZ_webSite </title>
    <link rel="stylesheet" type="text/css" media="screen" href="otrais.css" />
</head>

<body>
    <div class="Edgars">
        <img src="avatar1.jpg" alt=" " class="Edgars-img" ;>
        <h1>
        <?php         
        $sql="select lietVards as ' Lektors ', lietUzvards as ' ' from Lietotajs  where liet_id = 8;";
        
        echo "<!-- $sql -->";
        $sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
        tabula($sql_res);
          ?>
        </h1>
        

        <div class="zemEdgars">
            <form>
                <div class="info">
                    <a href="AirIndex.html">

                    </a>
                </div>
            </form>

            <div class = "zemEdgars"> <form>
           <div class = "info" >
               <a href="pasniedzejs1.html">
                <div class="info" onclick="izvele('c');">
                    Kursi
                </div>
             </a>
           </div></form>

           <div class = "zemEdgars"> <form>
           <div class = "info" >
           <?php
           $sql="select kurs_nosaukums as '' from Kurss where kurs_id = 9 ;";
        
        echo "<!-- $sql -->";
        $sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
        tabulaDivi($sql_res);
          ?>
           </div></form>
           
           <?php
           $sql="select lietVards as '.', lietUzvards as '' from Lietotajs where st_id = 2;";
        
        echo "<!-- $sql -->";
        $sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
        tabulaTris($sql_res);
          ?>

           

        </div>


        <style>
            table {
                width: 100%;
            }

            table,
            th,
            td {
                border: 1px solid black;
                border-collapse: collapse;
            }

            th,
            td {
                padding: 15px;
                text-align: left;
                color: white;

            }

            table#t01 tr:nth-child(even) {
                background-color: white;
            }

            table#t01 tr:nth-child(odd) {
                background-color: #fff;
            }

            table#t01 th {
                background-color: blue;
                color: red;
            }
        </style>
        <table>
            <tr>
                

            </tr>
            <tr>

                

            </tr>
            <tr>
                

            </tr>
            <tr>

               


            </tr>
            <tr>



            </tr>

            <tr>


            </tr>
        </table>
        <br>


<h6>@created by EZ 2018</h6>
        <div>
            
        </div>
        
    </div>
    
    </div>
    
    </div>





</body>

</html>

<?php
function tabula($sql_res) {
$first = true;
echo "<center><Edgars class=>";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<h1>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<a href=pasniedzejs.php style = 'color:white;'> $v</a> </br>";
        }
        echo "</tr>".PHP_EOL;
}
echo "</table></center>";


/* close result set */
mysqli_free_result($sql_res);
}

function tabulaDivi($sql_res) {
    $first = true;
    echo "<center> <class = \"info\"></br>";
    while ($row = mysqli_fetch_assoc($sql_res)) {
        if ($first) {
            echo "<h1></br>";
            foreach ($row as $k=>$v) {
                echo "<th>$k </th>";
            }
            echo "</tr>".PHP_EOL;
            $first = false;
        }
        echo "<tr>";
            foreach ($row as $v) {
             echo "<a href=pasniedzejs2.php style = 'color:white;'> $v</a> 
                 </br>"  ;
            }
            echo "</tr>".PHP_EOL;
    }
    echo "</table></center>";
    
    
    /* close result set */
    mysqli_free_result($sql_res);
    }

    function tabulaTris($sql_res) {
        $first = true;
        echo "<center> <class = \"info\"></br>";
        while ($row = mysqli_fetch_assoc($sql_res)) {
            if ($first) {
                echo "<h1>";
                foreach ($row as $k=>$v) {
                    echo "<th>$k </th>";
                    
                }
                echo "</tr>".PHP_EOL;
                $first = false;
            }
            echo "<tr>";
                foreach ($row as $v) {
                 echo "<a href=Pasniedzejs4.php style = 'color:white;'> $v</a> " ;
                }echo "</br></br>";
                echo "</tr>".PHP_EOL;
        }
        echo "</table></center>";
        
        
        /* close result set */
        mysqli_free_result($sql_res);
        }
?>