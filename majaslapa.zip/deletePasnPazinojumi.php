<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


if(isset($_GET['delete'])){
    $dala_id = $_GET['delete'];
    $sql = "delete from Pazinojumi where dala_id = $dala_id";
    $res = mysqli_query($d,$sql);
    $row = mysqli_fetch_array($res);
 

if(mysqli_query($d,$sql)){
    
}

if($_POST["delete"]){
    
   
   
    header("location: pasnPazinojumi.php");
   }
}

?>



            <form action = "" method = "Post">



<input type = "submit" name = "delete" value = "delete">

</form>
