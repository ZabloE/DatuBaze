<?php
$uname=$_POST['uname'];
$pass=$_POST['pass'];
$error="";
$succes="";

if(isset($_POST['submit'])){
 
    if($uname == "Arturs"){
        if($pass == "Irbe"){
            $error="";
            $succes="welcome";
            header("Location:otrais.php");
            
        }
        
        else{
            $error="Invalid passw";
            $succes="";
        }
    }
        else{
            $error="Invalid username";
            $succes="";
        }
    }

    if(isset($_POST['submit'])){
 
        if($uname == "user"){
            if($pass == "root"){
                $error="";
                $succes="welcome";
                header("Location:pasniedzejs.php");
                
            }
            
            else{
                $error="Invalid passw";
                $succes="";
            }
        }
            else{
                $error="Invalid username";
                $succes="";
            }
        }
    ?>



<!DOCTYPE html>
<html>



<body background="student.jpg">

<link rel="stylesheet" type="text/css" media="screen" href="pirma.css" />
<div class="Edgars">
    
    <h1>
        Ventspils Augstskola "VEA"
    </h1>
    <p class="error"><?php echo $error; ?></p class="error"><?php echo $error; ?></p>

    <div class="zemEdgars">
        <form method ="post">
            <div class="info" >
             
                <input type="submit" name="submit" value="Pieslegties">
                 
          <h5>Lietotajvards</h5>      
     <br/>           
<input type="text" name="uname" value="" placeholder= "enter username" required><br/>
<h5>
Parole<h5>
<input type="text" name="pass" value="" placeholder="enter password" required>
<h5><br>
</form>
           
        
    
   
    </form>
<div><footer>
    <h6>@created by EZ 2018</h6>


</footer>
</div>

 
</body>

</html>

<?php
//Step1
 $db = mysqli_connect('localhost','worldread','worldreadPaSS','Skola')
 or die('Error connecting to MySQL server.');

 function CheckLoginInDB($uname,$pass)
{
    if(!$this->DBLogin())
    {
        $this->HandleError("Database login failed!");
        return false;
    }          
    $uname = $this->SanitizeForSQL($uname);
    $pwdmd5 = md5($pass);
    $qry = "Select lietVards, lietUzvards from Lietotajs ".
        " where lietVards='$uname' and lietUzvards='$pass' ".
        " and confirmcode='y'";
    
    $result = mysql_query($qry,$this->connection);
    
    if(!$result || mysql_num_rows($result) <= 0)
    {
        $this->HandleError("Error logging in. ".
            "The username or password does not match");
        return false;
    }
    return true;
}

?>