<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


if(isset($_GET['insert'])){
    $p_id = $_GET['insert'];
    $sql="select atz_id as ID, p_id as Parbaudijums, atzime as Atzime from Atzimes where liet_id = 2 and kurs_id  =1 and atz_id = $p_id ;";
    $res = mysqli_query($d,$sql);
    $row = mysqli_fetch_array($res);

}

    if($_POST["atzime"] && $_POST["parbaudijums"]){
        if($_POST["insert"]){

            $atzime = $_POST["atzime"];
            $parbaudijums = $_POST["parbaudijums"];
            $date = date("y-m-d h:i:sa");
            $sql = "insert into Atzimes (liet_id,atzime,Atz_date, kurs_id,p_id) values(2,'$atzime','$date', 1, '$parbaudijums');";

           
            if(mysqli_query($d,$sql)){


            }
            header("location: pasnPazinojumi.php");
        }
    }

?>



            <form action = "" method = "Post">
atzime <input type ="text" name = "atzime" value = ""><br>
parbaudijums <input type ="text" name = "parbaudijums" value = ""><br>

<input type = "submit" name = "insert" value = "insert">

</form>