<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


if(isset($_GET['insert'])){
    $dala_id = $_GET['insert'];
    $sql="select dala_info, dala_virsraksts,st_id from Pazinojumi where dala_id = $dala_id";
    $res = mysqli_query($d,$sql);
    $row = mysqli_fetch_array($res);

}

if($_POST["Kurss"] && $_POST["Info"] && $_POST["st_id"]){
    if($_POST["insert"]){

        $Kurss = $_POST["Kurss"];
        $Info = $_POST["Info"];
        $st_id = $_POST["st_id"];
            $sql = "insert into Pazinojumi (dala_info,dala_virsraksts,st_id) values('$Kurss','$Info', '$st_id');";

           
            if(mysqli_query($d,$sql)){


            }
            header("location: pasnPazinojumi.php");
        }
    }

?>



            <form action = "" method = "Post">
            Kurss <input type ="text" name = "Kurss" value = "<?php echo $row[0];?>"><br>
Info <input type ="text" name = "Info" value = "<?php echo $row[1];?>"><br>
Programma <input type ="text" name = "st_id" value = "<?php echo $row[2];?>"><br>

<input type = "submit" name = "insert" value = "insert">

</form>