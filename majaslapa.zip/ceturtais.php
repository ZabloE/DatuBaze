<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");

?>


<!DOCTYPE html>
<html>
<head>
    <title>EZ_webSite </title>
    <link rel="stylesheet" type="text/css" media="screen" href="ceturtais.css" />
</head>

<body>
    <div class="Edgars">
        <img src="pic1.jpg.jpg" alt = " " class="Edgars-img";>
        <h1>
        <?php
        
        $sql="select lietVards as 'Seviks', lietUzvards as '' from Lietotajs where liet_id = 2;";
        
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabulaViens($sql_res);
  ?>
        </h1>
        <h5>Bakalaura programma  "Datorzinātnes"</h5>
       
        <div class = "zemEdgars"> <form>
           <div class = "info" >
             
           </div></form>

 <div class = "zemEdgars"> <form>
           <div class = "info" >
               <a href="tresais.php">
                <div class="info" onclick="izvele('c');">
                    ITF Kursi
                </div>
             </a>
           </div></form>       
           


           <div class = "zemEdgars"> <form>
           <div class = "info" >
           <?php
        
        $sql="select kurs_nosaukums as '' from Kurss where kurs_id = 9 ;";
        
echo "<!-- $sql -->";
$sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
tabulaDivi($sql_res);
  ?>
           </div></form>



     <div class = "info"> <form>
           <div class = "info" >
               <a href="piektais.php">
                <div class="info" onclick="izvele('c');">
                   Atzimes
                </div>
             </a>
           
           </div></form>



       <div class = "info" onclick = "izvele('c');">
      Gaidāmie notikumi
    </div>
  <div class = "info" onclick = "izvele('c');">
       Norises info
    </div>
    
  <div class = "info" onclick = "izvele('c');">
        Kabinets
    </div>
    </div>

  
    

    <div><h6>@created by EZ 2018</h6></div>
    </div>
</div>
</div>



<?php

function tabula($sql_res) {
$first = true;
echo "<center> <class = \"info\"></br>";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<h1></br>";
        foreach ($row as $k=>$v) {
            echo "<th>$k </th>";
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
         echo "<a href=ceturtais.php style = 'color:white;'> $v</a> 
             </br>"  ;
        }
        echo "</tr>".PHP_EOL;
}
echo "</table></center>";


/* close result set */
mysqli_free_result($sql_res);
}

function tabulaViens($sql_res) {
    $first = true;
    echo "<center> <class = \"info\"></br>";
    while ($row = mysqli_fetch_assoc($sql_res)) {
        if ($first) {
            echo "<h1></br>";
            foreach ($row as $k=>$v) {
                echo "<th>$k </th>";
            }
            echo "</tr>".PHP_EOL;
            $first = false;
        }
        echo "<tr>";
            foreach ($row as $v) {
             echo "<a href=otrais.php style = 'color:white;'> $v</a> 
                 </br>"  ;
            }
            echo "</tr>".PHP_EOL;
    }
    echo "</table></center>";
    
    
    /* close result set */
    mysqli_free_result($sql_res);
    }

    function tabulaDivi($sql_res) {
        $first = true;
        echo "<center> <class = \"info\"></br>";
        while ($row = mysqli_fetch_assoc($sql_res)) {
            if ($first) {
                echo "<h1></br>";
                foreach ($row as $k=>$v) {
                    echo "<th>$k </th>";
                }
                echo "</tr>".PHP_EOL;
                $first = false;
            }
            echo "<tr>";
                foreach ($row as $v) {
                 echo "<a href=tresais.php style = 'color:white;'> $v</a> 
                     </br>"  ;
                }
                echo "</tr>".PHP_EOL;
        }
        echo "</table></center>";
        
        
        /* close result set */
        mysqli_free_result($sql_res);
        }

      

?>
