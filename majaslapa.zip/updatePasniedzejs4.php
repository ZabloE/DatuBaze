
<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


if(isset($_GET['edit'])){
    $p_id = $_GET['edit'];
    $sql="select atz_id as ID, p_id as Parbaudijums, atzime as Atzime from Atzimes where liet_id = 2 and kurs_id  =1 and atz_id = $p_id ;";
    $res = mysqli_query($d,$sql);
    $row = mysqli_fetch_array($res);

}

    if($_POST["atzime"] && $_POST["parbaudijums"]){
        if($_POST["Update"]){

            $atzime = $_POST["atzime"];
            $parbaudijums = $_POST["parbaudijums"];

            $sql = "Update Atzimes set atzime = '$atzime' where atz_id = $p_id";

            if(mysqli_query($d,$sql)){


            }
            header("location: Pasniedzejs4.php");
        }
    }

?>



            <form action = "" method = "Post">
atzime <input type ="text" name = "atzime" value = "<?php echo $row[2];?>"><br>
parbaudijums <input type ="text" name = "parbaudijums" value = "<?php echo $row[1];?>"><br>

<input type = "submit" name = "Update" value = "Update">

</form>