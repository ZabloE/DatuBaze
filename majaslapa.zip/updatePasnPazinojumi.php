<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");


if(isset($_GET['edit'])){
    $dala_id = $_GET['edit'];
    $sql="select dala_info, dala_virsraksts,st_id from Pazinojumi where dala_id = $dala_id";
    $res = mysqli_query($d,$sql);
    $row = mysqli_fetch_array($res);

}

    if($_POST["Kurss"] && $_POST["Info"] && $_POST["st_id"]){
        if($_POST["Update"]){

            $Kurss = $_POST["Kurss"];
            $Info = $_POST["Info"];
            $st_id = $_POST["st_id"];

          

            $sql = "Update Pazinojumi set dala_info = '$Kurss',  dala_virsraksts = '$Info' , st_id = '$st_id' where dala_id = $dala_id";

            if(mysqli_query($d,$sql)){


            }
            header("location: pasnPazinojumi.php");
        }
    }

?>



            <form action = "" method = "Post">
Kurss <input type ="text" name = "Kurss" value = "<?php echo $row[0];?>"><br>
Info <input type ="text" name = "Info" value = "<?php echo $row[1];?>"><br>
Programma <input type ="text" name = "st_id" value = "<?php echo $row[2];?>"><br>

<input type = "submit" name = "Update" value = "Update">

</form>