<?php
$d = mysqli_connect('localhost','worldread','worldreadPaSS','Skola') or die('Nevaru pievienoties datubāzei');
$chs=mysqli_set_charset($d, "utf8");

?>

<!DOCTYPE html>
<html>
<head>
    <title>EZ_webSite </title>
    <link rel="stylesheet" type="text/css" media="screen" href="otrais.css" />
</head>

<style>

body {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #ddd;
    padding: 8px;
}

tr:nth-child(even){background-color: transparent;}
tr:hover {background-color: #ddd;}

th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: transparent;
    color: white;
}

</style>
</head>
<body>
    <div class="Edgars">
        <img src="avatar1.jpg" alt=" " class="Edgars-img" ;>
        <h1>
          <?php         
        $sql="select lietVards as ' Lektors ', lietUzvards as ' ' from Lietotajs  where liet_id = 8;";
        
        echo "<!-- $sql -->";
        $sql_res = mysqli_query($d,$sql) or die("<h1>".mysqli_error()."</h1>");
        tabula($sql_res);
          ?>
        </h1>
      

        <div class="zemEdgars">
            <form>
                <div class="info">
                    <a href="AirIndex.html">

                    </a>
                </div>
            </form>

            <div class="zemEdgars">
                <form>
                    <div class="info">
                        <a href=pasniedzejs1.php style = 'color:white'>
                           Kursi
                        </a>
                    </div>
                </form>

                <div class="info" onclick="izvele('c');">
                <a href = pasnPazinojumi.php style='color:white'>
                    Paziņojumi
                    </a>
                </div>
            </div>
            <div>
                   </div>
    <a href = pirma.php style='color:white'> logout </a>
    </div>  
            </div>

        </div>
   
    </div>
 <h6>@created by EZ 2018</h6>
    </div>




</body>


<?php

function tabula($sql_res) {
$first = true;
echo "<center><Edgars class=>";
while ($row = mysqli_fetch_assoc($sql_res)) {
    if ($first) {
        echo "<h1>";
        foreach ($row as $k=>$v) {
            echo "<th>$k</th>";
        }
        echo "</tr>".PHP_EOL;
        $first = false;
    }
    echo "<tr>";
        foreach ($row as $v) {
            echo "<td>$v</td>";
        }
        echo "</tr>".PHP_EOL;
}
echo "</table></center>";


/* close result set */
mysqli_free_result($sql_res);
}


?>